/*
 * main.c – STM32F103 + Kondo HTH4 compatibility firmware
 *
 * Peripherals used
 *   USB FS  – CDC virtual COM port  (HTH4 host communication)
 *   USART1  – ICS 3.5 half-duplex   (servo bus, PA9)
 *   SysTick – 1 ms timebase
 *
 * Build with STM32CubeMX-generated USB CDC middleware (usbd_cdc_if.c)
 * or replace CDC_Transmit_Bytes with your own send function.
 */

#include "stm32f1xx_hal.h"
#include "rcb4.h"
#include "ics.h"
#include "motion.h"

/* ── USB CDC interface glue ──────────────────────────────────────────────── */
/* These symbols are provided by STM32 USB CDC middleware.                   */
extern uint8_t CDC_Transmit_FS(uint8_t *Buf, uint16_t Len);

/* Called by RCB-4 engine to send response bytes to HTH4 */
void CDC_Transmit_Bytes(const uint8_t *buf, uint16_t len) {
    CDC_Transmit_FS((uint8_t *)buf, len);
}

/* ── Called by USB CDC middleware on every received packet ───────────────── */
/* Hook this into usbd_cdc_if.c → CDC_Receive_FS()                           */
void App_CDC_Receive(uint8_t *buf, uint32_t len) {
    for (uint32_t i = 0; i < len; i++)
        RCB4_Feed(buf[i]);
}

/* ── Clock configuration: 72 MHz from 8 MHz HSE via PLL ─────────────────── */
static void SystemClock_Config(void) {
    RCC_OscInitTypeDef osc = {0};
    osc.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
    osc.HSEState            = RCC_HSE_ON;
    osc.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
    osc.PLL.PLLState        = RCC_PLL_ON;
    osc.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
    osc.PLL.PLLMUL          = RCC_PLL_MUL9;     /* 8 × 9 = 72 MHz */
    HAL_RCC_OscConfig(&osc);

    RCC_ClkInitTypeDef clk = {0};
    clk.ClockType      = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                         RCC_CLOCKTYPE_PCLK1  | RCC_CLOCKTYPE_PCLK2;
    clk.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
    clk.AHBCLKDivider  = RCC_SYSCLK_DIV1;
    clk.APB1CLKDivider = RCC_HCLK_DIV2;   /* APB1 = 36 MHz (USART1 clk src) */
    clk.APB2CLKDivider = RCC_HCLK_DIV1;
    HAL_RCC_ClockConfig(&clk, FLASH_LATENCY_2);

    /* USB requires 48 MHz on the USB clock.
     * With 72 MHz SYSCLK: USB prescaler = 1.5  → 48 MHz  */
    __HAL_RCC_USB_CLK_ENABLE();
}

/* ── LED on PC13 (blue pill on-board LED) ─────────────────────────────────  */
static void LED_Init(void) {
    __HAL_RCC_GPIOC_CLK_ENABLE();
    GPIO_InitTypeDef g = {0};
    g.Pin   = GPIO_PIN_13;
    g.Mode  = GPIO_MODE_OUTPUT_PP;
    g.Speed = GPIO_SPEED_FREQ_LOW;
    HAL_GPIO_Init(GPIOC, &g);
    HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET); /* LED off (active low) */
}

/* ── Application entry point ─────────────────────────────────────────────── */
int main(void) {
    HAL_Init();
    SystemClock_Config();
    LED_Init();

    ICS_Init();
    Motion_Init();
    RCB4_Init();

    /* USB CDC initialisation is done by MX_USB_DEVICE_Init() generated
     * by CubeMX.  Call it here if you integrate the generated files:    */
    /* MX_USB_DEVICE_Init(); */

    /* Blink LED to signal boot */
    for (int i = 0; i < 6; i++) {
        HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
        HAL_Delay(100);
    }

    uint32_t last_tick = 0;

    while (1) {
        uint32_t now = HAL_GetTick();

        /* 1 ms tasks */
        if (now - last_tick >= 1) {
            last_tick = now;
            RCB4_Tick();   /* advances motion playback */

            /* Reflect play state on LED */
            if (Motion_IsPlaying())
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET); /* on  */
            else
                HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET);   /* off */
        }
    }
}
