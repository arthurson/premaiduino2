/*
 * ics.c – Kondo ICS 3.5 half-duplex bus driver for STM32F103
 *
 * Hardware mapping
 *   USART1  TX = PA9   (servo bus, half-duplex)
 *   The TX line doubles as RX in half-duplex mode via a single-wire connection.
 *   An external 1kΩ pull-up to +3.3 V is required on the shared wire.
 *
 * Baud rate: 1 250 000 bps, 8N1
 */

#include "ics.h"
#include "stm32f1xx_hal.h"
#include <string.h>

/* ── private state ───────────────────────────────────────────────────────── */
static UART_HandleTypeDef huart_ics;
static ICS_Servo servos[ICS_MAX_ID + 1];

/* ── helpers ─────────────────────────────────────────────────────────────── */

/* Switch USART1 between TX (drive) and RX (listen) in half-duplex mode */
static void ics_set_dir_tx(void) {
    __HAL_UART_DISABLE(&huart_ics);
    huart_ics.Instance->CR1 &= ~USART_CR1_RE;   /* disable RX */
    huart_ics.Instance->CR1 |=  USART_CR1_TE;   /* enable  TX */
    __HAL_UART_ENABLE(&huart_ics);
}

static void ics_set_dir_rx(void) {
    __HAL_UART_DISABLE(&huart_ics);
    huart_ics.Instance->CR1 &= ~USART_CR1_TE;   /* disable TX */
    huart_ics.Instance->CR1 |=  USART_CR1_RE;   /* enable  RX */
    __HAL_UART_ENABLE(&huart_ics);
    /* flush any stale data */
    __HAL_UART_CLEAR_FLAG(&huart_ics, UART_FLAG_RXNE);
}

/* Transmit bytes then switch to RX, return number of reply bytes read */
static int ics_transaction(const uint8_t *tx, uint8_t tx_len,
                            uint8_t *rx, uint8_t rx_len,
                            uint32_t timeout_ms)
{
    ics_set_dir_tx();
    if (HAL_UART_Transmit(&huart_ics, (uint8_t *)tx, tx_len, 10) != HAL_OK)
        return -1;

    /* wait for TX shift-register to empty (≈ tx_len × 8 µs @ 1.25 Mbps) */
    HAL_Delay(1);

    ics_set_dir_rx();
    if (rx && rx_len) {
        if (HAL_UART_Receive(&huart_ics, rx, rx_len, timeout_ms) != HAL_OK)
            return -1;
        return rx_len;
    }
    return 0;
}

/* ── public API ──────────────────────────────────────────────────────────── */

void ICS_Init(void) {
    memset(servos, 0, sizeof(servos));

    /* Enable clocks */
    __HAL_RCC_USART1_CLK_ENABLE();
    __HAL_RCC_GPIOA_CLK_ENABLE();

    /* PA9 – USART1_TX, alternate-function push-pull */
    GPIO_InitTypeDef gpio = {0};
    gpio.Pin   = GPIO_PIN_9;
    gpio.Mode  = GPIO_MODE_AF_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOA, &gpio);

    huart_ics.Instance          = USART1;
    huart_ics.Init.BaudRate     = ICS_BAUD;
    huart_ics.Init.WordLength   = UART_WORDLENGTH_8B;
    huart_ics.Init.StopBits     = UART_STOPBITS_1;
    huart_ics.Init.Parity       = UART_PARITY_NONE;
    huart_ics.Init.Mode         = UART_MODE_TX_RX;
    huart_ics.Init.HwFlowCtl   = UART_HWCONTROL_NONE;
    huart_ics.Init.OverSampling = UART_OVERSAMPLING_16;
    HAL_UART_Init(&huart_ics);
}

/* Move servo id to pos (ICS units).  Returns true on success. */
bool ICS_SetPosition(uint8_t id, uint16_t pos) {
    if (id > ICS_MAX_ID) return false;
    if (pos < ICS_POS_MIN) pos = ICS_POS_MIN;
    if (pos > ICS_POS_MAX) pos = ICS_POS_MAX;

    uint8_t tx[3];
    tx[0] = ICS_CMD_POSITION | (id & 0x1F);
    tx[1] = (uint8_t)((pos >> 7) & 0x7F);
    tx[2] = (uint8_t)(pos & 0x7F);

    uint8_t rx[3];
    if (ics_transaction(tx, 3, rx, 3, 5) < 0)
        return false;

    uint16_t ret_pos = ((uint16_t)(rx[1] & 0x7F) << 7) | (rx[2] & 0x7F);
    servos[id].pos     = ret_pos;
    servos[id].present = true;
    return true;
}

/* Release servo torque */
bool ICS_Free(uint8_t id) {
    if (id > ICS_MAX_ID) return false;
    uint8_t tx[3] = { ICS_CMD_POSITION | (id & 0x1F), 0, 0 };
    uint8_t rx[3];
    return (ics_transaction(tx, 3, rx, 3, 5) >= 0);
}

/* Read a parameter (stretch/speed/current/temp) */
bool ICS_ReadParam(uint8_t id, uint8_t param, uint8_t *out) {
    if (id > ICS_MAX_ID || !out) return false;
    uint8_t tx[2] = { ICS_CMD_READ | (id & 0x1F), param & 0x1F };
    uint8_t rx[2];
    if (ics_transaction(tx, 2, rx, 2, 5) < 0) return false;
    *out = rx[1] & 0x7F;
    return true;
}

/* Write a parameter */
bool ICS_WriteParam(uint8_t id, uint8_t param, uint8_t val) {
    if (id > ICS_MAX_ID) return false;
    uint8_t tx[3] = {
        ICS_CMD_WRITE | (id & 0x1F),
        param & 0x1F,
        val   & 0x7F
    };
    uint8_t rx[3];
    return (ics_transaction(tx, 3, rx, 3, 5) >= 0);
}

/* Return current position in ICS units, or -1 on error */
int16_t ICS_GetPosition(uint8_t id) {
    if (id > ICS_MAX_ID) return -1;
    uint8_t tx[3] = { ICS_CMD_POSITION | (id & 0x1F), 0, 0 };
    uint8_t rx[3];
    if (ics_transaction(tx, 3, rx, 3, 5) < 0) return -1;
    return (int16_t)(((uint16_t)(rx[1] & 0x7F) << 7) | (rx[2] & 0x7F));
}
