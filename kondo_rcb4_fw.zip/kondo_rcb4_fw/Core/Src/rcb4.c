/*
 * rcb4.c – Kondo RCB-4 protocol emulator
 *
 * Receives bytes from USB-CDC (HTH4 host), parses packets, dispatches
 * commands to the ICS bus and motion engine, builds responses.
 *
 * Packet format (host → board)
 *   [0]  LEN   – total bytes including LEN and SUM
 *   [1]  CMD   – command opcode
 *   [2..LEN-2] DATA
 *   [LEN-1]    SUM  – XOR of bytes [0..LEN-2]
 *
 * Response format (board → host):
 *   [0]  LEN
 *   [1]  ACK (0x06 = OK, 0x15 = ERR)
 *   [2..LEN-2] DATA (if any)
 *   [LEN-1]    SUM
 */

#include "rcb4.h"
#include "ics.h"
#include "motion.h"
#include "stm32f1xx_hal.h"
#include <string.h>

/* Forward-declared: implemented at bottom – sends bytes over USB CDC */
extern void CDC_Transmit_Bytes(const uint8_t *buf, uint16_t len);

/* ── Internal state ──────────────────────────────────────────────────────── */
static RCB4_RxState rx;
static uint8_t ram[RCB4_RAM_SIZE];

/* ── Helpers ─────────────────────────────────────────────────────────────── */

static uint8_t checksum(const uint8_t *buf, uint8_t len) {
    uint8_t s = 0;
    for (uint8_t i = 0; i < len; i++) s ^= buf[i];
    return s;
}

static void send_response(uint8_t ack, const uint8_t *data, uint8_t data_len) {
    uint8_t pkt[RCB4_MAX_PACKET];
    pkt[0] = 3 + data_len;   /* LEN */
    pkt[1] = ack;
    if (data && data_len)
        memcpy(&pkt[2], data, data_len);
    pkt[2 + data_len] = checksum(pkt, 2 + data_len);
    CDC_Transmit_Bytes(pkt, pkt[0]);
}

static void ack_ok(void)  { send_response(RCB4_ACK_OK,  NULL, 0); }
static void ack_err(void) { send_response(RCB4_ACK_ERR, NULL, 0); }

/* ── Convert between RCB-4 servo units and ICS units ────────────────────── */
/* RCB-4 stores positions as uint16 in range 3500-11500 (same as ICS). */

static uint16_t rcb4_to_ics(uint16_t v) { return v; }
static uint16_t ics_to_rcb4(uint16_t v) { return v; }

/* ── Command dispatcher ──────────────────────────────────────────────────── */

static void dispatch(const uint8_t *pkt) {
    uint8_t cmd      = pkt[1];
    const uint8_t *d = &pkt[2];
    uint8_t dlen     = pkt[0] - 3;   /* data bytes = LEN - 3 */

    switch (cmd) {

    /* ── GET_ACK: simple ping ─────────────────────────────────────────── */
    case RCB4_CMD_GET_ACK:
        ack_ok();
        break;

    /* ── SINGLE_MOVE: move one servo ──────────────────────────────────── */
    case RCB4_CMD_SINGLE_MOVE: {
        /* d[0]=id, d[1..2]=pos (LE), d[3]=speed */
        if (dlen < 4) { ack_err(); break; }
        uint8_t  id  = d[0];
        uint16_t pos = (uint16_t)d[1] | ((uint16_t)d[2] << 8);
        /* speed currently ignored (HTH4 uses frame-level speed) */
        if (!ICS_SetPosition(id, rcb4_to_ics(pos))) { ack_err(); break; }
        /* mirror to RAM */
        ram[RAM_SERVO_BASE + id * 2]     = d[1];
        ram[RAM_SERVO_BASE + id * 2 + 1] = d[2];
        ack_ok();
        break;
    }

    /* ── CONST_MOVE: move with constant speed ─────────────────────────── */
    case RCB4_CMD_CONST_MOVE: {
        /* same layout as SINGLE_MOVE */
        if (dlen < 4) { ack_err(); break; }
        uint8_t  id  = d[0];
        uint16_t pos = (uint16_t)d[1] | ((uint16_t)d[2] << 8);
        if (!ICS_SetPosition(id, rcb4_to_ics(pos))) { ack_err(); break; }
        ram[RAM_SERVO_BASE + id * 2]     = d[1];
        ram[RAM_SERVO_BASE + id * 2 + 1] = d[2];
        ack_ok();
        break;
    }

    /* ── ALL_SERVO_MOVE: move up to 36 servos at once ─────────────────── */
    case RCB4_CMD_ALL_SERVO_MOVE: {
        /* d[0]=count, then count×3 bytes: id, posL, posH */
        if (dlen < 1) { ack_err(); break; }
        uint8_t cnt = d[0];
        if (dlen < (uint8_t)(1 + cnt * 3)) { ack_err(); break; }
        for (uint8_t i = 0; i < cnt; i++) {
            uint8_t  id  = d[1 + i * 3];
            uint16_t pos = (uint16_t)d[2 + i * 3] | ((uint16_t)d[3 + i * 3] << 8);
            ICS_SetPosition(id, rcb4_to_ics(pos));
            ram[RAM_SERVO_BASE + id * 2]     = d[2 + i * 3];
            ram[RAM_SERVO_BASE + id * 2 + 1] = d[3 + i * 3];
        }
        ack_ok();
        break;
    }

    /* ── VECTOR_MOVE: interpolated move (treated like ALL_SERVO_MOVE) ─── */
    case RCB4_CMD_VECTOR_MOVE: {
        if (dlen < 1) { ack_err(); break; }
        uint8_t cnt = d[0];
        if (dlen < (uint8_t)(1 + cnt * 3)) { ack_err(); break; }
        for (uint8_t i = 0; i < cnt; i++) {
            uint8_t  id  = d[1 + i * 3];
            uint16_t pos = (uint16_t)d[2 + i * 3] | ((uint16_t)d[3 + i * 3] << 8);
            ICS_SetPosition(id, rcb4_to_ics(pos));
        }
        ack_ok();
        break;
    }

    /* ── PLAY_MOTION ──────────────────────────────────────────────────── */
    case RCB4_CMD_PLAY_MOTION: {
        if (dlen < 1) { ack_err(); break; }
        uint8_t slot = d[0];
        ram[RAM_MOTION_NO]  = slot;
        ram[RAM_PLAYSTATE]  = 1;
        if (!Motion_Play(slot)) { ack_err(); break; }
        ack_ok();
        break;
    }

    /* ── STOP_MOTION ──────────────────────────────────────────────────── */
    case RCB4_CMD_STOP_MOTION:
        Motion_Stop();
        ram[RAM_PLAYSTATE] = 0;
        ack_ok();
        break;

    /* ── PAUSE / RESUME ───────────────────────────────────────────────── */
    case RCB4_CMD_PAUSE:
        Motion_Stop();
        ack_ok();
        break;

    case RCB4_CMD_RESUME:
        Motion_Play(ram[RAM_MOTION_NO]);
        ack_ok();
        break;

    /* ── READ_RAM ─────────────────────────────────────────────────────── */
    case RCB4_CMD_READ_RAM: {
        /* d[0]=addr, d[1]=len */
        if (dlen < 2) { ack_err(); break; }
        uint8_t addr = d[0];
        uint8_t rlen = d[1];
        if ((uint16_t)addr + rlen > RCB4_RAM_SIZE) { ack_err(); break; }
        /* Update dynamic RAM fields before reading */
        ram[RAM_PLAYSTATE] = Motion_IsPlaying() ? 1 : 0;
        ram[RAM_MOTION_NO] = Motion_CurrentSlot();
        send_response(RCB4_ACK_OK, &ram[addr], rlen);
        break;
    }

    /* ── WRITE_RAM ────────────────────────────────────────────────────── */
    case RCB4_CMD_WRITE_RAM: {
        /* d[0]=addr, d[1]=len, d[2..]=data */
        if (dlen < 2) { ack_err(); break; }
        uint8_t addr = d[0];
        uint8_t wlen = d[1];
        if ((uint16_t)addr + wlen > RCB4_RAM_SIZE) { ack_err(); break; }
        if (dlen < (uint8_t)(2 + wlen)) { ack_err(); break; }
        memcpy(&ram[addr], &d[2], wlen);
        ack_ok();
        break;
    }

    /* ── READ_ROM ─────────────────────────────────────────────────────── */
    case RCB4_CMD_READ_ROM: {
        /* d[0..1]=offset (LE), d[2]=len */
        if (dlen < 3) { ack_err(); break; }
        uint16_t offset = (uint16_t)d[0] | ((uint16_t)d[1] << 8);
        uint8_t  rlen   = d[2];
        uint8_t  buf[64];
        if (rlen > 64 || !Motion_ReadROM(offset, buf, rlen)) { ack_err(); break; }
        send_response(RCB4_ACK_OK, buf, rlen);
        break;
    }

    /* ── WRITE_ROM ────────────────────────────────────────────────────── */
    case RCB4_CMD_WRITE_ROM: {
        /* d[0..1]=offset (LE), d[2]=len, d[3..]=data */
        if (dlen < 3) { ack_err(); break; }
        uint16_t offset = (uint16_t)d[0] | ((uint16_t)d[1] << 8);
        uint8_t  wlen   = d[2];
        if (dlen < (uint8_t)(3 + wlen)) { ack_err(); break; }
        if (!Motion_WriteROM(offset, &d[3], wlen)) { ack_err(); break; }
        ack_ok();
        break;
    }

    /* ── READ_AD: return analog channel values ─────────────────────────── */
    case RCB4_CMD_READ_AD: {
        /* d[0]=channel mask, return up to 8 channels × 2 bytes */
        uint8_t buf[16] = {0};
        uint8_t mask    = dlen ? d[0] : 0xFF;
        uint8_t pos2    = 0;
        for (uint8_t ch = 0; ch < 8; ch++) {
            if (mask & (1u << ch)) {
                /* Read STM32 ADC – placeholder, returns 0x0200 (mid-range) */
                buf[pos2++] = 0x00;
                buf[pos2++] = 0x02;
            }
        }
        send_response(RCB4_ACK_OK, buf, pos2);
        break;
    }

    /* ── READ_IO ──────────────────────────────────────────────────────── */
    case RCB4_CMD_READ_IO: {
        uint8_t io_val = ram[RAM_IO_IN];
        send_response(RCB4_ACK_OK, &io_val, 1);
        break;
    }

    /* ── WRITE_IO ─────────────────────────────────────────────────────── */
    case RCB4_CMD_WRITE_IO: {
        if (dlen < 1) { ack_err(); break; }
        ram[RAM_IO_OUT] = d[0];
        /* Drive GPIO here if needed */
        ack_ok();
        break;
    }

    /* ── ZERO_RESET: center all servos ───────────────────────────────── */
    case RCB4_CMD_ZERO_RESET:
        for (uint8_t id = 0; id < RCB4_MAX_SERVOS; id++)
            ICS_SetPosition(id, ICS_POS_CENTER);
        ack_ok();
        break;

    /* ── SINGLE_PARAM: read servo position ───────────────────────────── */
    case RCB4_CMD_SINGLE_PARAM: {
        if (dlen < 1) { ack_err(); break; }
        uint8_t id = d[0];
        int16_t pos = ICS_GetPosition(id);
        if (pos < 0) { ack_err(); break; }
        uint16_t upos = ics_to_rcb4((uint16_t)pos);
        uint8_t resp[2] = { (uint8_t)(upos & 0xFF), (uint8_t)(upos >> 8) };
        send_response(RCB4_ACK_OK, resp, 2);
        break;
    }

    default:
        ack_err();
        break;
    }
}

/* ── Public API ──────────────────────────────────────────────────────────── */

void RCB4_Init(void) {
    memset(&rx,  0, sizeof(rx));
    memset(ram,  0, sizeof(ram));
}

/* Feed one byte from CDC RX */
void RCB4_Feed(uint8_t byte) {
    if (!rx.active) {
        /* First byte = LEN */
        if (byte < 3 || byte > RCB4_MAX_PACKET) return;  /* sanity */
        rx.buf[0] = byte;
        rx.len    = byte;
        rx.cnt    = 1;
        rx.active = true;
        return;
    }
    rx.buf[rx.cnt++] = byte;
    if (rx.cnt < rx.len) return;

    /* Full packet received – verify checksum */
    uint8_t expected = checksum(rx.buf, rx.len - 1);
    rx.active = false;
    if (rx.buf[rx.len - 1] != expected) {
        ack_err();
        return;
    }
    dispatch(rx.buf);
}

/* Call from main loop to advance motion playback */
void RCB4_Tick(void) {
    Motion_Tick();
}
