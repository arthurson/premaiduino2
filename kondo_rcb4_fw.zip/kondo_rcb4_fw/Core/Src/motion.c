/*
 * motion.c – Motion ROM storage & playback engine
 *
 * ROM is emulated in the STM32F103's internal flash (last 8 KB sector).
 * For simplicity this implementation uses a RAM shadow that can be written
 * via HTH4 WRITE_ROM commands and persisted with a flush operation.
 */

#include "motion.h"
#include "ics.h"
#include "stm32f1xx_hal.h"
#include <string.h>
#include <stddef.h>

/* ── ROM shadow in RAM (8 KB) ────────────────────────────────────────────── */
static uint8_t rom_shadow[RCB4_ROM_SIZE];

/* ── Playback state ──────────────────────────────────────────────────────── */
static struct {
    bool     playing;
    uint8_t  slot;
    uint8_t  frame;
    uint16_t loop;
    uint32_t next_tick;   /* HAL_GetTick() target for next frame */
} play;

/* Helper: locate slot in ROM shadow */
static MotionSlot *slot_ptr(uint8_t slot_no) {
    if (slot_no >= MOTION_MAX_SLOTS) return NULL;
    return (MotionSlot *)(rom_shadow + (uint32_t)slot_no
                          * (offsetof(MotionSlot, frames)
                             + MOTION_MAX_FRAMES * sizeof(MotionFrame)));
}

/* ── Public API ──────────────────────────────────────────────────────────── */

void Motion_Init(void) {
    memset(rom_shadow, 0xFF, sizeof(rom_shadow));
    memset(&play, 0, sizeof(play));
}

bool Motion_WriteROM(uint16_t offset, const uint8_t *data, uint16_t len) {
    if ((uint32_t)offset + len > RCB4_ROM_SIZE) return false;
    memcpy(rom_shadow + offset, data, len);
    return true;
}

bool Motion_ReadROM(uint16_t offset, uint8_t *data, uint16_t len) {
    if ((uint32_t)offset + len > RCB4_ROM_SIZE) return false;
    memcpy(data, rom_shadow + offset, len);
    return true;
}

bool Motion_Play(uint8_t slot_no) {
    MotionSlot *s = slot_ptr(slot_no);
    if (!s || s->frame_count == 0 || s->frame_count > MOTION_MAX_FRAMES)
        return false;
    play.playing   = true;
    play.slot      = slot_no;
    play.frame     = 0;
    play.loop      = s->loop_count;
    play.next_tick = HAL_GetTick();
    return true;
}

void Motion_Stop(void) {
    play.playing = false;
}

bool    Motion_IsPlaying(void)    { return play.playing; }
uint8_t Motion_CurrentSlot(void)  { return play.slot;    }

/* Call frequently (e.g., every ms from main loop) */
void Motion_Tick(void) {
    if (!play.playing) return;
    if (HAL_GetTick() < play.next_tick) return;

    MotionSlot  *s = slot_ptr(play.slot);
    MotionFrame *f = &s->frames[play.frame];

    /* Send all servo positions in this frame */
    for (uint8_t id = 0; id < RCB4_MAX_SERVOS; id++) {
        if (f->servo_mask & (1u << (id % 8)))
            ICS_SetPosition(id, f->pos[id]);
    }

    /* Advance: speed byte = centiseconds per frame */
    uint32_t delay_ms = (f->speed ? f->speed : 1) * 10u;
    play.next_tick = HAL_GetTick() + delay_ms;

    play.frame++;
    if (play.frame >= s->frame_count) {
        if (play.loop > 1) {
            play.loop--;
            play.frame = 0;
        } else if (play.loop == 0) {
            /* 0 = infinite loop */
            play.frame = 0;
        } else {
            play.playing = false;
        }
    }
}
