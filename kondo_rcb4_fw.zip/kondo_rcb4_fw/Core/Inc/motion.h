#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ── Motion ROM layout ───────────────────────────────────────────────────── */
/* 80 motion slots, each up to 100 frames, each frame = 36 servo positions   */
#define MOTION_MAX_SLOTS   80
#define MOTION_MAX_FRAMES  100
#define MOTION_FRAME_SIZE  (36 * 2 + 4)  /* 36 servos ×2 bytes + header    */

typedef struct __attribute__((packed)) {
    uint8_t  speed;       /* frame playback speed  */
    uint8_t  accel;       /* acceleration          */
    uint8_t  servo_mask;  /* which servos are used */
    uint8_t  reserved;
    uint16_t pos[36];     /* servo positions       */
} MotionFrame;

typedef struct __attribute__((packed)) {
    uint8_t  frame_count;
    uint8_t  flags;
    uint16_t loop_count;
    MotionFrame frames[MOTION_MAX_FRAMES];
} MotionSlot;

void    Motion_Init(void);
bool    Motion_WriteROM(uint16_t offset, const uint8_t *data, uint16_t len);
bool    Motion_ReadROM(uint16_t offset, uint8_t *data, uint16_t len);
bool    Motion_Play(uint8_t slot_no);
void    Motion_Stop(void);
void    Motion_Tick(void);          /* advance playback state machine */
bool    Motion_IsPlaying(void);
uint8_t Motion_CurrentSlot(void);
