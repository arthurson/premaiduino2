#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ── RCB-4 command opcodes ───────────────────────────────────────────────── */
#define RCB4_CMD_SINGLE_MOVE      0x00
#define RCB4_CMD_CONST_MOVE       0x01
#define RCB4_CMD_ALL_SERVO_MOVE   0x02
#define RCB4_CMD_VECTOR_MOVE      0x03
#define RCB4_CMD_PLAY_MOTION      0x04
#define RCB4_CMD_STOP_MOTION      0x05
#define RCB4_CMD_GET_ACK          0x06
#define RCB4_CMD_READ_RAM         0x07
#define RCB4_CMD_WRITE_RAM        0x08
#define RCB4_CMD_READ_ROM         0x09
#define RCB4_CMD_WRITE_ROM        0x0A
#define RCB4_CMD_READ_IO          0x0B
#define RCB4_CMD_WRITE_IO         0x0C
#define RCB4_CMD_READ_AD          0x0D
#define RCB4_CMD_SET_BRANCH       0x0E
#define RCB4_CMD_SET_MOTION_PLAY  0x0F
#define RCB4_CMD_PAUSE            0x10
#define RCB4_CMD_RESUME           0x11
#define RCB4_CMD_ZERO_RESET       0x12
#define RCB4_CMD_SINGLE_PARAM     0x13

/* ── Packet limits ───────────────────────────────────────────────────────── */
#define RCB4_MAX_PACKET   128
#define RCB4_MAX_SERVOS   36
#define RCB4_RAM_SIZE     256
#define RCB4_ROM_SIZE     (8 * 1024)   /* 8 KB motion ROM */

/* ── RAM map offsets ─────────────────────────────────────────────────────── */
#define RAM_SERVO_BASE    0x00   /* 36×2 bytes servo pos  (0x00-0x47) */
#define RAM_SWITCH        0x48
#define RAM_AD_BASE       0x50   /* 8 AD channels ×2                  */
#define RAM_FLAGS         0x60
#define RAM_MOTION_NO     0x61
#define RAM_PLAYSTATE     0x62
#define RAM_IO_OUT        0x70
#define RAM_IO_IN         0x71

/* ── Response / ACK ──────────────────────────────────────────────────────── */
#define RCB4_ACK_OK       0x06
#define RCB4_ACK_ERR      0x15

typedef struct {
    uint8_t  buf[RCB4_MAX_PACKET];
    uint8_t  len;        /* expected total length (from buf[0]) */
    uint8_t  cnt;        /* bytes received so far              */
    bool     active;
} RCB4_RxState;

void RCB4_Init(void);
void RCB4_Feed(uint8_t byte);
void RCB4_Tick(void);          /* call from SysTick / main loop */
