#pragma once
#include <stdint.h>
#include <stdbool.h>

/* ── ICS 3.5 constants ───────────────────────────────────────────────────── */
#define ICS_BAUD          1250000UL   /* 1.25 Mbps half-duplex */
#define ICS_MAX_ID        35
#define ICS_POS_MIN       3500
#define ICS_POS_MAX       11500
#define ICS_POS_CENTER    7500

/* ── Sub-commands ────────────────────────────────────────────────────────── */
#define ICS_CMD_POSITION  0x80
#define ICS_CMD_READ      0xA0
#define ICS_CMD_WRITE     0xC0
#define ICS_CMD_ID        0xE0

/* ── Parameter IDs (READ/WRITE) ──────────────────────────────────────────── */
#define ICS_PARAM_STRETCH 1
#define ICS_PARAM_SPEED   2
#define ICS_PARAM_CURRENT 3
#define ICS_PARAM_TEMP    4

typedef struct {
    uint16_t pos;       /* last known position  (ICS units 3500-11500) */
    uint8_t  stretch;
    uint8_t  speed;
    bool     present;
} ICS_Servo;

void  ICS_Init(void);
bool  ICS_SetPosition(uint8_t id, uint16_t pos);
bool  ICS_Free(uint8_t id);
bool  ICS_ReadParam(uint8_t id, uint8_t param, uint8_t *out);
bool  ICS_WriteParam(uint8_t id, uint8_t param, uint8_t val);
int16_t ICS_GetPosition(uint8_t id);  /* returns -1 on error */
