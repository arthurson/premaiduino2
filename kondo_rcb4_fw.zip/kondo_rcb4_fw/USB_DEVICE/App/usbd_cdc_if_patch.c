/*
 * usbd_cdc_if_patch.c
 *
 * This file shows the ONLY change needed in the STM32CubeMX-generated
 * usbd_cdc_if.c to connect USB CDC to the RCB-4 protocol engine.
 *
 * In your generated usbd_cdc_if.c, locate CDC_Receive_FS() and add
 * the single call shown below.  Everything else stays as generated.
 */

/* ── Excerpt from generated usbd_cdc_if.c ─────────────────────────────── */

#include "usbd_cdc_if.h"
#include "rcb4.h"   /* <── ADD THIS INCLUDE */

/* ... (generated code) ... */

static int8_t CDC_Receive_FS(uint8_t *Buf, uint32_t *Len) {
    /* Forward every received byte to the RCB-4 protocol engine */
    App_CDC_Receive(Buf, *Len);          /* <── ADD THIS LINE */

    USBD_CDC_SetRxBuffer(&hUsbDeviceFS, &Buf[0]);
    USBD_CDC_ReceivePacket(&hUsbDeviceFS);
    return (USBD_OK);
}

/* ... (rest of generated code unchanged) ... */
