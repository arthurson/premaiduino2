# STM32F103 ↔ Kondo HTH4 Compatibility Firmware

Emulates a **Kondo RCB-4HV** control board on a standard "Blue Pill"
(STM32F103C8T6) so that the **HTH4** Windows software works without
modification.

---

## Architecture

```
HTH4 (PC)
   │  USB CDC (virtual COM port)
   │
STM32F103
  ├─ USB FS  ←→  RCB-4 protocol engine  (rcb4.c)
  │                     │
  │               motion engine  (motion.c)
  │                     │
  └─ USART1 PA9 ──→ ICS 3.5 servo bus   (ics.c)
                        │
                   Kondo servos (KRS-xxxx / KRS-4xxx)
```

---

## Hardware connections

| Signal          | STM32F103 pin | Notes                                      |
|-----------------|---------------|--------------------------------------------|
| USB D−          | PA11          | Direct to USB connector                    |
| USB D+          | PA12          | Direct to USB connector                    |
| ICS servo bus   | PA9           | Single wire via 1 kΩ to servo connector    |
| +3.3 V pull-up  | PA9           | 1 kΩ resistor between PA9 and 3.3 V rail   |
| LED (status)    | PC13          | On-board Blue Pill LED (active low)        |

> **ICS wiring:** Connect PA9 through a 1 kΩ resistor to the DATA pin
> of the Kondo servo connector.  The same node is both TX and RX
> (half-duplex).  Do **not** connect PA10 (USART1_RX) — it is unused.

---

## Building

### Prerequisites
- `arm-none-eabi-gcc` ≥ 10
- STM32CubeMX (generate a CDC project for STM32F103C8T6)
- CMake ≥ 3.22

### Steps

1. **Generate USB CDC base project** with STM32CubeMX:
   - MCU: STM32F103C8T6
   - Connectivity → USB → Device (FS)
   - Middleware → USB Device → CDC
   - Clock: HSE 8 MHz → PLL → 72 MHz, USB prescaler 1.5 → 48 MHz
   - Generate code (HAL, CMake or Makefile)

2. **Copy** the four custom source files into the generated project:
   ```
   Core/Inc/rcb4.h
   Core/Inc/ics.h
   Core/Inc/motion.h
   Core/Src/rcb4.c
   Core/Src/ics.c
   Core/Src/motion.c
   ```

3. **Patch** `USB_DEVICE/App/usbd_cdc_if.c`:
   - Add `#include "rcb4.h"` near the top.
   - In `CDC_Receive_FS()`, add one line:
     ```c
     App_CDC_Receive(Buf, *Len);
     ```

4. **Replace / merge** `Core/Src/main.c` with the supplied `main.c`
   (keep the CubeMX `MX_USB_DEVICE_Init()` call and add
   `ICS_Init(); Motion_Init(); RCB4_Init();` after it).

5. **Build**:
   ```bash
   mkdir build && cd build
   cmake .. -DCMAKE_TOOLCHAIN_FILE=../arm-none-eabi.cmake
   make -j4
   ```

6. **Flash** with ST-Link or DFU:
   ```bash
   st-flash write build/kondo_rcb4_fw.bin 0x08000000
   # or
   dfu-util -a 0 -s 0x08000000:leave -D build/kondo_rcb4_fw.bin
   ```

---

## RCB-4 Commands Implemented

| Opcode | Name             | Status      |
|--------|-----------------|-------------|
| 0x00   | SINGLE_MOVE      | ✅ Full     |
| 0x01   | CONST_MOVE       | ✅ Full     |
| 0x02   | ALL_SERVO_MOVE   | ✅ Full     |
| 0x03   | VECTOR_MOVE      | ✅ Full     |
| 0x04   | PLAY_MOTION      | ✅ Full     |
| 0x05   | STOP_MOTION      | ✅ Full     |
| 0x06   | GET_ACK (ping)   | ✅ Full     |
| 0x07   | READ_RAM         | ✅ Full     |
| 0x08   | WRITE_RAM        | ✅ Full     |
| 0x09   | READ_ROM         | ✅ Full     |
| 0x0A   | WRITE_ROM        | ✅ Full     |
| 0x0B   | READ_IO          | ✅ Stub     |
| 0x0C   | WRITE_IO         | ✅ Stub     |
| 0x0D   | READ_AD          | ✅ Stub*    |
| 0x0E   | SET_BRANCH       | ✅ ACK only |
| 0x0F   | SET_MOTION_PLAY  | ✅ ACK only |
| 0x10   | PAUSE            | ✅ Full     |
| 0x11   | RESUME           | ✅ Full     |
| 0x12   | ZERO_RESET       | ✅ Full     |
| 0x13   | SINGLE_PARAM     | ✅ Full     |

> \* READ_AD returns mid-range (0x0200) placeholder values.  Wire the
> STM32 ADC channels to real sensors and replace the stub in `rcb4.c`
> `RCB4_CMD_READ_AD` handler.

---

## USB Descriptor (Windows Driver)

HTH4 uses a standard CDC ACM device.  The CubeMX-generated USB stack
sets **VID = 0x0483 / PID = 0x5740** by default.  Windows 10/11
installs `usbser.sys` automatically — no custom driver needed.

If HTH4 requires a specific VID/PID (matching the genuine RCB-4 USB
adapter), edit `USB_DEVICE/App/usbd_desc.c`:

```c
#define USBD_VID     0x0483   /* change to Kondo VID if required */
#define USBD_PID_FS  0x5740   /* change to Kondo PID if required */
```

---

## Motion ROM Persistence

The motion ROM is held in a RAM shadow (`rom_shadow[]` in `motion.c`).
It is **lost on power-cycle** unless you add flash persistence.

To persist motions, call `HAL_FLASH_Program()` to write `rom_shadow`
to the last page(s) of the 64 KB flash.  A minimal flash page write
helper is included as a commented-out section in `motion.c`.

---

## LED Status

| PC13 LED   | Meaning                           |
|------------|-----------------------------------|
| Blink ×3   | Firmware boot                     |
| Off        | Idle / connected                  |
| On solid   | Motion playing                    |

---

## Servo Count

The firmware supports up to **36 servos** (ICS IDs 0–35), matching the
RCB-4HV maximum.  In practice, the ICS bus speed limits simultaneous
movement to ~20 servos with smooth motion.
